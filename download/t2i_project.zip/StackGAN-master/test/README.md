# Test Folder
This is a folder to store trained images after every 25 epochs to check the model performance.
