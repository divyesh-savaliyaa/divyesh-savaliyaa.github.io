# Weights
A directory to store all your training weights after every 25 epochs.
